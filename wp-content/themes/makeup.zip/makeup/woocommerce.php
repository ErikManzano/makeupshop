<?php get_header(); ?>

    <main class="container py-5 justify-content-center">
        <?php
            woocommerce_content();
        ?>
    </main>
    
<?php get_footer(); ?>